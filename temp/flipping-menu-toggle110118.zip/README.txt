A Pen created at CodePen.io. You can find this one at https://codepen.io/hexagoncircle/pen/dJMERy.

 What the flip is this? Not ideal for prod but here's a fun menu toggle experiment with css animations.